package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.concurrent.TimeUnit;

public class ComprasPage {

    WebDriver driver;
    public ComprasPage(WebDriver driver) {
        this.driver = driver;
    }

    public void acessarAplicacao() {
        driver.manage().window().maximize();  //Comando para maximizar a tela
        driver.get("https://www.cinemark.com.br/cotia");
    }

    public void clicaremcompreaqui(){
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
        driver.findElement(By.xpath("//a[contains(text(),'Compre Aqui')]")).click();
    }

    public void clicaremprosseguir(){
            driver.findElement(By.id("btnProsseguir")).click();
    }

    public void clicarementrar(){
            driver.findElement(By.id("c")).click();
    }

    public void preencheemail(){
        driver.findElement(By.id("Email")).click();
        driver.findElement(By.id("Email")).sendKeys("Deborahpreka@gmail.com");
    }

    public void preenchesenha(){
        driver.findElement(By.id("Password")).click();
        driver.findElement(By.id("Password")).sendKeys("Teste01");
    }
}
