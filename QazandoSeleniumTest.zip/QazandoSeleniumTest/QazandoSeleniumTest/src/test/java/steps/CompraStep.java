package steps;

import cucumber.api.java.pt.Dado;
import cucumber.api.java.pt.E;
import cucumber.api.java.pt.Entao;
import cucumber.api.java.pt.Quando;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import pages.ComprasPage;
import support.Utils;

import static runner.RunCucumberTest.driver;

public class CompraStep extends Utils {   //extends serve para importar uma classe de outro lugar, herança

    ComprasPage comprasPage = new ComprasPage(driver);  //Chamando os comandos do comprasPage dentro da compraStep

    @Dado("^que estou no site do cinemark")
    public void acessar_site_cinemark() {  ///Essa sessão é como se fosse uma tag, para acessar esse metodo em outros lugares
        comprasPage.acessarAplicacao();
    }

    @Quando("^clico em progamação$")
    public void botao_progamacao() {
        driver.findElement(By.xpath("//a[contains(text(),'Programação')]")).click();
    }

    @E("^clico na opção em cartaz$")
    public void opcao_emcartaz() {
        driver.findElement(By.xpath("//div[@id=\'navbar\']/ul/li/div/div/ul/li/a/span")).click();
    }

    @E("^clico em sinopse e horario$")
    public void opcao_sinopse() {
        driver.findElement(By.xpath("(//a[contains(text(),\'Sinopse e horários\')])[2]")).click();
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("window.scrollBy(0,1000)", "");
    }

    @E("^clico em compre aqui$")
    public void botao_compreaqui() {
        comprasPage.clicaremcompreaqui();
    }

    @E("^escolho uma sessão$")
    public void escolher_sessao() throws InterruptedException {
        driver.findElement(By.xpath("//*[@id=\"sessionDates\"]/a[2]")).click();
        driver.findElement(By.id("movieSession_")).click();
        driver.manage().window().setSize(new Dimension(1920, 1080));
    }

    @E("^escolho um assento$")
    public void escolho_assento(){
        WebElement searchButton = driver.findElement(By.xpath("//*[@id=\"focal-seats\"]/div[1]/div/div[3]"));
        JavascriptExecutor js = (JavascriptExecutor)driver;
        js.executeScript("arguments[0].click()", searchButton);
    }

    @E("^clico em prosseguir$")
    public void clico_prosseguir() {
        comprasPage.clicaremprosseguir();
    }

    @E("^seleciono o tipo de ingresso inteira$")
    public void seleciono_ingresso() {
        driver.findElement(By.id("plusButton_0_0")).click();
    }

    @E("^insiro o email$")
    public void insiro_email() {
      comprasPage.preencheemail();
    }

    @E("^insiro a senha$")
    public void insiro_senha() {
       comprasPage.preenchesenha();
    }

    @E("^clico em entrar$")
    public void clico_entrar() {
        comprasPage.clicarementrar();
    }

    @E("^clico em Nao obrigado no popup$")
    public void rejeitar_popup_de_snack() {
        esperarElementoEstarPresente(By.xpath("//*[@id=\"modal-snack\"]/div/div/div/a"), 10); // aguarda até ao elemento estar na tela
        driver.findElement(By.xpath("//*[@id=\"modal-snack\"]/div/div/div/a")).click();
    }

    @E("^clico em pagamento$")
    public void botao_pagamento() {
        driver.findElement(By.id("totalValue")).click();
    }

    @E("^preencho o campo numero do cartão$")
    public void numero_cartao() {
        driver.findElement(By.id("CardNumber")).sendKeys("1234 1234 1234 1234");
    }

    @E("^preencho o campo nome impresso$")
    public void campo_nome() {
        driver.findElement(By.id("HolderName")).sendKeys("Senhora teste");
    }

    @E("^preencho o campo CPF do titular$")
    public void CPF_Titular() {
        driver.findElement(By.id("CPF")).sendKeys("12345678912");
    }

    @E("^preencho o campo mes e ano$")
    public void data_expiracao() {
        driver.findElement(By.id("ExpiryDate")).sendKeys("1234");
    }

    @E("^preencho o CVV$")
    public void cvv() {
        driver.findElement(By.id("SecurityCode")).sendKeys("123");
    }

    @Entao("^visualizo o botão de finalizar pedido$")
    public void finalizar_pedido()
    {
        Assert.assertEquals(true, driver.findElement(By.id("confirmOrder")).isDisplayed()); //verificar se o elemento está visivel na tela
    }
    }






