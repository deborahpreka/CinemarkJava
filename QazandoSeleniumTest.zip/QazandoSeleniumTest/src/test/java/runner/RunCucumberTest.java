package runner;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        plugin = {},   ///Vamos colocar as configurações do report de testes
        features = "src/test/resources/features",  ///A pasta aonde os bdd vão ficar
        tags = {"~@ignore"}, ///Aonde vão ficar as tags de testes
        glue = {"steps"}  /// Aonde estão os steps
)
public class RunCucumberTest {
}
